# Snyk Local Code Engine <!-- omit in toc -->

- [Introduction](#introduction)
- [Prerequisites](#prerequisites)
- [Getting Started](#getting-started)
- [Enabling CLI and PR Checks](#enabling-cli-and-pr-checks)
- [Cluster with Cloud Load Balancer](#cluster-with-cloud-load-balancer)
  - [Checking Cluster Health](#checking-cluster-health)
- [Cluster without Cloud Load Balancer](#cluster-without-cloud-load-balancer)
- [Enabling TLS](#enabling-tls)
- [Parameters](#parameters)
  - [Global required parameters](#global-required-parameters)
  - [Global optional parameters](#global-optional-parameters)
  - [Broker parameters](#broker-parameters)
    - [GitHub.com parameters](#githubcom-parameters)
    - [GitHub Enterprise parameters](#github-enterprise-parameters)
    - [GitLab parameters](#gitlab-parameters)
    - [Bitbucket server parameters](#bitbucket-server-parameters)
    - [Azure Repos parameters](#azure-repos-parameters)
  - [codeapi](#codeapi)
  - [bundle](#bundle)
  - [suggest](#suggest)
  - [broker-client](#broker-client)
  - [deeproxy](#deeproxy)
  - [nginx-ingress-controller](#nginx-ingress-controller)
  - [service-health-aggregator](#service-health-aggregator)
- [3rd-party charts](#3rd-party-charts)
- [Chart Usage](#chart-usage)
- [Logging](#logging)
- [Uninstalling Snyk Code Local Engine](#uninstalling-snyk-code-local-engine)

## Introduction

This documentation details how Snyk Local Code Engine can be deployed on a Kubernetes cluster using Helm package manager.

## Prerequisites

- Kubernetes version 1.16.0 - 1.21.5
- 3 nodes with following specs:
  - CPU 32 cores
  - RAM 120GB
  - Disk 500 GB (>300GB Ephemeral Storage)
- Helm 3.5.0

## Getting Started

Configure Local Engine in `values.yaml`. For basic installation, only image pulling credentials and Broker settings are required.

If you would rather not include one or more tokens/credentials in values.yaml, you can include them as arguments when running the Helm chart. However, we recommend that you configure other values.yaml to simplify upgrades & troubleshooting.

Example:

```bash
helm upgrade <RELEASE_NAME> . -i \
--set global.imagePullSecret.credentials.username="<SNYK_REGISTRY_USER>" \
--set global.imagePullSecret.credentials.password='<SNYK_REGISTRY_PASSWORD>'
```

The above command installs or, if a release already exists, upgrades Snyk Code Local Engine. If the deployment was successful you will be able to scan a project via Snyk web portal using the same SCM integration.

## Enabling CLI and PR Checks

Snyk Code Local Engine services needs to be accessible from outside the cluster for CLI and PR checks to work. For this, deployment settings varies depending on how your cluster is configured. In all cases, cluster-specific settings are an addition to the settings in [Getting Started](#getting-started) section.

Steps to enable the feature vary, if you have:

- [Cluster with Cloud Load Balancer](#cluster-with-cloud-load-balancer)
- [Cluster without Cloud Load Balancer](#cluster-without-cloud-load-balancer)

Skip to the section that is relevant to you.

## Cluster with Cloud Load Balancer

If your cluster uses a LoadBalancer from AWS or GCP, do changes in `values.yaml ` as follows and upgrade the release:

- `global.ingress.enabled` to `true`
- `global.localEngineUrl` to a DNS pointing to ingress' LoadBalancer IP/DNS. Example: http://local-engine.domain

Ingress' LoadBalancer IP/DNS is the `EXTERNAL-IP` of `nginx-ingress-controller` that can be seen with:

```bash
kubectl get svc <RELEASE_NAME>-nginx-ingress-controller
```

NOTE: by default, IP/DNS provided by cloud providers for LoadBalancers are dynamic which means that if you uninstall and redeploy the engine you might have to update any DNS that might be pointing to it.

However, if you have static IP configured (not supported for AWS, instructions for GKE are [here](https://cloud.google.com/compute/docs/ip-addresses/reserve-static-external-ip-address#reserve_new_static)), you can set `--set nginx-ingress-controller.service.loadBalancerIP=<STATIC_IP>` to `helm upgrade` command and it will assign controller the static IP.

### Checking Cluster Health

To check if everything works, run:

```bash
curl -L http://<LOCAL_ENGINE_URL>/
> 302 -> <LOCAL_ENGINE_URL>/status
```

and

```bash
curl http://<LOCAL_ENGINE_URL>/broker/healthcheck
```

and

```bash
curl http://<LOCAL_ENGINE_URL>/api/healthcheck
```

For the first check, the response should be: `"Snyk Code is healthy! 🐶"`

For the second, you should see something similar: `{"ok":true,"websocketConnectionOpen":true,"brokerServerUrl":"https://broker.snyk.io","version":"4.116.0"}`

For the third, you should see: `{"gitSha":"sha","ok":true}`

## Cluster without Cloud Load Balancer

_Note:_ This section does not apply for clusters using cloud resources, like a load balancers. See section [Cloud Native LoadBalancer](#cloud-native-loadbalancer) on how to enable external access in that case

1. Run `helm upgrade` from [Getting Started](#getting-started) and append the following arguments

```
--set nginx-ingress-controller.service.nodePorts.http="<PORT>" \
--set nginx-ingress-controller.service.type="NodePort"
```

- `<PORT>` - any port that falls into Kubenetes NodePort's range, which is 30000 - 32767.

We recommend to restrict any other access to the entrypoint, specifically from any sources in the internet.

2. Identify the `NODE_IP` of the `nginx-ingress-controller`'s pod. You can get it using:

```bash
kubectl get pods -o wide
```

3. Check if this setup was successful by running the [healthcheck steps](#checking-cluster-health). Your `IP/DNS` will be `<NODE_IP>:<PORT>`.

## Enabling TLS

By default, the ingress endpoints are insecure. In order to secure them using TLS, you need to make the following changes in the `values.yaml` file:

```
global:
  ...
  ingress:
    ...
    host: "<HOST>"
    tls:
      enabled: true
      secret:
        ...
        key: |
          <KEY>
        cert: |
          <CERT>
```

With `<HOST>` being the DNS used when the TLS `<CERT>` and `<KEY>` were generated.
Read more about securing an ingress with TLS [here](https://kubernetes.io/docs/concepts/services-networking/ingress/#tls) and TLS secrets [in general](https://kubernetes.io/docs/concepts/configuration/secret/#tls-secrets).

---

## Parameters

### Global required parameters

| Name                                          | Description                  | Default Value |
| --------------------------------------------- | ---------------------------- | ------------- |
| `global.imagePullSecret.credentials.username` | Docker hub registry username | `""`          |
| `global.imagePullSecret.credentials.password` | Docker hub registry password | `""`          |

### Global optional parameters

| Name                                    | Description                                                                            | Default Value                       |
| --------------------------------------- | -------------------------------------------------------------------------------------- | ----------------------------------- |
| `global.ingress.enable`                 | Enable Ingress                                                                         | `false`                             |
| `global.ingress.installController`      | Nginx ingress controller, required only if no cloud-based ingress controller is in use | `false`                             |
| `global.ingress.ingressClassName`       | Ingress controller class name                                                          | `"nginx"`                           |
| `global.ingress.host`                   | Ingress host                                                                           | `""`                                |
| `global.ingress.annotations`            | Additional annotations for the ingress resource                                        | `{}`                                |
| `global.ingress.tls.enabled`            | Enable TLS for the ingress endpoints                                                   | `false`                             |
| `global.ingress.tls.secret.name`        | Name of the secret to use for the ingress.                                             | `"{{ .Release.Name }}-ingress-tls"` |
| `global.ingress.tls.secret.key`         | TLS key that will be used to create an ingress secret                                  | `""`                                |
| `global.ingress.tls.secret.cert`        | TLS certificate that will be used to create an ingress secret                          | `""`                                |
| `global.ingress.tls.secret.annotations` | Additional annotations for the auto-generated TLS secret resource                      | `{}`                                |

### Broker parameters

| Name                       | Description                                                                                         | Default Value |
| -------------------------- | --------------------------------------------------------------------------------------------------- | ------------- |
| `broker-client.brokerType` | Type of broker client to use. supported options: github-com, github-enterprise, gitlab, azure-repos | `""`          |

Please use _one_ of the following SCM configuration

#### GitHub.com parameters

| Name                        | Description                   | Default Value |
| --------------------------- | ----------------------------- | ------------- |
| `broker-client.githubToken` | Token for <http://github.com> | `""`          |

#### GitHub Enterprise parameters

| Name                          | Description                              | Default Value                                     |
| ----------------------------- | ---------------------------------------- | ------------------------------------------------- |
| `broker-client.githubToken`   | Token for <http://github.com>            | `""`                                              |
| `broker-client.githubHost`    | Host name for GitHub server              | `""`                                              |
| `broker-client.githubApi`     | GitHub REST API url, excluding scheme    | `"{{ .Values.broker-client.githubHost }}/api/v3"` |
| `broker-client.githubGraphql` | GitHub GraphQL API url, excluding scheme | `"{{ .Values.broker-client.githubHost }}/api"`    |

#### GitLab parameters

| Name                        | Description                 | Default Value |
| --------------------------- | --------------------------- | ------------- |
| `broker-client.gitlabToken` | GitLab Host                 | `""`          |
| `broker-client.gitlabHost`  | Host name for gitlab server | `""`          |

#### Bitbucket server parameters

| Name                              | Description                    | Default Value |
| --------------------------------- | ------------------------------ | ------------- |
| `broker-client.bitbucketUsername` | Bitbucket username             | `""`          |
| `broker-client.bitbucketPassword` | Bitbucket password             | `""`          |
| `broker-client.bitbucketHost`     | Host name for bitbucket server | `""`          |

#### Azure Repos parameters

| Name                            | Description               | Default Value |
| ------------------------------- | ------------------------- | ------------- |
| `broker-client.azureReposToken` | Token for Azure Repos     | `""`          |
| `broker-client.azureReposHost`  | Host name for Azure Repos | `""`          |
| `broker-client.azureReposOrg`   | Azure organization name   | `""`          |

### codeapi

| Name                                 | Description                                                                           | Default Value |
| ------------------------------------ | ------------------------------------------------------------------------------------- | ------------- |
| `codeapi.imagePullSecrets`           | Docker registry secret names as an array                                              | `[]`          |
| `codeapi.nameOverride`               | String to partially override names.fullname template (will maintain the release name) | `""`          |
| `codeapi.fullnameOverride`           | String to fully override names.fullname template                                      | `""`          |
| `codeapi.serviceAccount.create`      | Specify whether a ServiceAccount should be created                                    | `true`        |
| `codeapi.serviceaccount.name`        | The name of the ServiceAccount to create                                              | `""`          |
| `codeapi.serviceAccount.annotations` | Additional Service Account annotations (evaluated as a template)                      | `{}`          |
| `codeapi.podAnnotations`             | Pod annotations                                                                       | `{}`          |
| `codeapi.podSecurityContext`         | Security context for pod                                                              | `{}`          |
| `codeapi.securityContext`            | holds security configuration that will be applied to a container                      | `{}`          |
| `codeapi.nodeSelector`               | Aggregator Node labels for pod assignment                                             | `{}`          |
| `codeapi.tolerations`                | Aggregator Tolerations for pod assignment                                             | `[]`          |
| `codeapi.affinity`                   | Forwarder Affinity for pod assignment                                                 | `{}`          |

### bundle

| Name                                | Description                                                                           | Default Value |
| ----------------------------------- | ------------------------------------------------------------------------------------- | ------------- |
| `bundle.imagePullSecrets`           | Docker registry secret names as an array                                              | `[]`          |
| `bundle.nameOverride`               | String to partially override names.fullname template (will maintain the release name) | `""`          |
| `bundle.fullnameOverride`           | String to fully override names.fullname template                                      | `""`          |
| `bundle.serviceAccount.create`      | Specify whether a ServiceAccount should be created                                    | `true`        |
| `bundle.serviceaccount.name`        | The name of the ServiceAccount to create                                              | `""`          |
| `bundle.serviceAccount.annotations` | Additional Service Account annotations (evaluated as a template)                      | `{}`          |
| `bundle.podAnnotations`             | Pod annotations                                                                       | `{}`          |
| `bundle.podSecurityContext`         | Security context for pod                                                              | `{}`          |
| `bundle.securityContext`            | Holds security configuration that will be applied to a container                      | `{}`          |
| `bundle.nodeSelector`               | Aggregator Node labels for pod assignment                                             | `{}`          |
| `bundle.tolerations`                | Aggregator Tolerations for pod assignment                                             | `[]`          |
| `bundle.affinity`                   | Forwarder Affinity for pod assignment                                                 | `{}`          |

### suggest

| Name                                 | Description                                                                           | Default Value |
| ------------------------------------ | ------------------------------------------------------------------------------------- | ------------- |
| `suggest.imagePullSecrets`           | Docker registry secret names as an array                                              | `[]`          |
| `suggest.nameOverride`               | String to partially override names.fullname template (will maintain the release name) | `""`          |
| `suggest.fullnameOverride`           | String to fully override names.fullname template                                      | `""`          |
| `suggest.serviceAccount.create`      | Specify whether a ServiceAccount should be created                                    | `true`        |
| `suggest.serviceaccount.name`        | The name of the ServiceAccount to create                                              | `""`          |
| `suggest.serviceAccount.annotations` | Additional Service Account annotations (evaluated as a template)                      | `{}`          |
| `suggest.podAnnotations`             | Pod annotations                                                                       | `{}`          |
| `suggest.podSecurityContext`         | Security context for pod                                                              | `{}`          |
| `suggest.securityContext`            | holds security configuration that will be applied to a container                      | `{}`          |
| `suggest.nodeSelector`               | Aggregator Node labels for pod assignment                                             | `{}`          |
| `suggest.tolerations`                | Aggregator Tolerations for pod assignment                                             | `[]`          |
| `suggest.affinity`                   | Forwarder Affinity for pod assignment                                                 | `{}`          |

### broker-client

| Name                                           | Description                                                                                     | Default Value |
| ---------------------------------------------- | ----------------------------------------------------------------------------------------------- | ------------- |
| `broker-client.codeSnippet.enabled`            | Enable code Snippets                                                                            | `false`       |
| `broker-client.imagePullSecrets`               | Docker registry secret names as an array                                                        | `[]`          |
| `broker-client.nameOverride`                   | String to partially override names.fullname template (will maintain the release name)           | `""`          |
| `broker-client.fullnameOverride`               | String to fully override names.fullname template                                                | `""`          |
| `broker-client.serviceAccount.create`          | Specify whether a ServiceAccount should be created                                              | `true`        |
| `broker-client.serviceaccount.name`            | The name of the ServiceAccount to create                                                        | `""`          |
| `broker-client.serviceAccount.annotations`     | Additional Service Account annotations (evaluated as a template)                                | `{}`          |
| `broker-client.podAnnotations`                 | Pod annotations                                                                                 | `{}`          |
| `broker-client.podSecurityContext`             | Security context for pod                                                                        | `{}`          |
| `broker-client.securityContext`                | Holds security configuration that will be applied to a container                                | `{}`          |
| `broker-client.nodeSelector`                   | Aggregator Node labels for pod assignment                                                       | `{}`          |
| `broker-client.tolerations`                    | Aggregator Tolerations for pod assignment                                                       | `[]`          |
| `broker-client.affinity`                       | Forwarder Affinity for pod assignment                                                           | `{}`          |
| `broker-client.ingress.enabled`                | Enable exposing the client via an ingress                                                       | `false`       |
| `broker-client.ingress.host`                   | Specifies which host the ingress will be configured for                                         | `""`          |
| `broker-client.ingress.annotations`            | Additional annotations for the ingress resource                                                 | `{}`          |
| `broker-client.ingress.tls.enabled`            | Enable TLS for the ingress endpoints                                                            | `false`       |
| `broker-client.ingress.tls.secret.name`        | Name of the secret to use for the ingress. Leave empty to default to `{servicename}-tls-secret` | `""`          |
| `broker-client.ingress.tls.secret.key`         | TLS key that will be used to create an ingress secret                                           | `""`          |
| `broker-client.ingress.tls.secret.cert`        | TLS certificate that will be used to create an ingress secret                                   | `""`          |
| `broker-client.ingress.tls.secret.annotations` | Additional annotations for the auto-generated TLS secret resource                               | `{}`          |

### deeproxy

| Name                                  | Description                                                      | Default Value |
| ------------------------------------- | ---------------------------------------------------------------- | ------------- |
| `deeproxy.serviceAccount.create`      | Specify whether a ServiceAccount should be created               | `true`        |
| `deeproxy.serviceaccount.name`        | The name of the ServiceAccount to create                         | `""`          |
| `deeproxy.serviceAccount.annotations` | Additional Service Account annotations (evaluated as a template) | `{}`          |
| `deeproxy.nodeSelector`               | Aggregator Node labels for pod assignment                        | `{}`          |
| `deeproxy.tolerations`                | Aggregator Tolerations for pod assignment                        | `[]`          |
| `deeproxy.affinity`                   | Forwarder Affinity for pod assignment                            | `{}`          |

### nginx-ingress-controller

| Name                                               | Description                      | Default Value    |
| -------------------------------------------------- | -------------------------------- | ---------------- |
| `nginx-ingress-controller.service.nodePorts.http`  | Specify the nodePort http value  | `""`             |
| `nginx-ingress-controller.service.nodePorts.https` | Specify the nodePort https value | `""`             |
| `nginx-ingress-controller.service.type`            | Service type                     | `"LoadBalancer"` |

### service-health-aggregator

_Either_ set `clusterRole` or `Role` to be created, do not set both.

| Name                                                           | Description                                                                                                                                                                       | Default Value                      |
| -------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `service-health-aggregator.healthchecks`                       | A list of objects with keys `namespace` (`string`), `enabled` (`bool`) and `services` (`[]string`). Leave empty to default to all services (`["*"]`) in the deployment namespace. | `[]`                               |
| `service-health-aggregator.healthyMessage`                     | The message to return when targeted services/pods are healthy                                                                                                                     | `"Targeted Services are healthy."` |
| `service-health-aggregator.imagePullSecrets`                   | Docker registry secret names as an array                                                                                                                                          | `[]`                               |
| `service-health-aggregator.nameOverride`                       | String to partially override names.fullname template (will maintain the release name)                                                                                             | `""`                               |
| `service-health-aggregator.fullnameOverride`                   | String to fully override names.fullname template                                                                                                                                  | `""`                               |
| `service-health-aggregator.role.create`                        | Specify whether a Role should be created                                                                                                                                          | `true`                             |
| `service-health-aggregator.role.annotations`                   | Additional Role annotations (evaluated as a template)                                                                                                                             | `{}`                               |
| `service-health-aggregator.role.permissions.namespaces`        | A list of namespaces to allow access to (leave empty to default to the deployment namespace)                                                                                      | `[]`                               |
| `service-health-aggregator.role.name`                          | The name of a pre-existing Role to use                                                                                                                                            | `""`                               |
| `service-health-aggregator.clusterRole.create`                 | Specify whether a ClusterRole should be created                                                                                                                                   | `true`                             |
| `service-health-aggregator.clusterRole.annotations`            | Additional ClusterRole annotations (evaluated as a template)                                                                                                                      | `{}`                               |
| `service-health-aggregator.clusterRole.permissions.namespaces` | A list of namespaces to allow access to (leave empty to default to the deployment namespace)                                                                                      | `[]`                               |
| `service-health-aggregator.clusterRole.name`                   | The name of a pre-existing ClusterRole to use                                                                                                                                     | `""`                               |
| `service-health-aggregator.serviceAccount.create`              | Specify whether a ServiceAccount should be created                                                                                                                                | `true`                             |
| `service-health-aggregator.serviceAccount.name`                | The name of the ServiceAccount to create                                                                                                                                          | `""`                               |
| `service-health-aggregator.serviceAccount.annotations`         | Additional Service Account annotations (evaluated as a template)                                                                                                                  | `{}`                               |
| `service-health-aggregator.nodeSelector`                       | Aggregator Node labels for pod assignment                                                                                                                                         | `{}`                               |
| `service-health-aggregator.tolerations`                        | Aggregator Tolerations for pod assignment                                                                                                                                         | `[]`                               |
| `service-health-aggregator.affinity`                           | Forwarder Affinity for pod assignment                                                                                                                                             | `{}`                               |

## 3rd-party charts

If you are looking to configure some of the 3rd-pary services that we are using on your own, your can find example for those charts here:

- [Ambassador](https://github.com/emissary-ingress/emissary/tree/master/charts/emissary-ingress)
- [Redis](https://github.com/bitnami/charts/tree/master/bitnami/redis)
- [Fluentd](https://github.com/bitnami/charts/tree/master/bitnami/fluentd)

## Chart Usage

The `values.yaml` file may be edited according to specific requirements. 

Alternatively, you can specify your own YAML file that contains values for required parameters when installing/upgrading the chart. For example:

`$ helm install my-release -f your-values.yaml`

## Logging

Fluentd is used to aggregate all our services' logs into one file.

The log file is rotated daily unless the file exceeded `fluentd-umbrella.logrotate.fileMaxSizeInMb` (default 500) and the number of files logrotate keeps is `fluentd-umbrella.logrotate.filesToKeep` (default 14). This means a log file for the whole day will be generated only the day after, unless it exceeds `fileMaxSizeInMb`.

Logrotate will validate that the number of log files is not above `fluentd-umbrella.logrotate.filesToKeep` by removing the oldest log file when the number of log files is equal to `filesToKeep`+1 files.

When a file is rotated the date and time of rotation is added as a suffix to the file name. If you want to see the current logs you would need to tail the `code.log` file. For fetching logs that written in the past you would pick the log file with date and time _after_ the timeframe you would like to see.

To fetch all log files to current directory run:

```console
kubectl cp <your-namespace>/<your-release>-fluentd-0:/var/log/snyk/logs ./
```

To fetch log files for specific dates first get exsiting logs list by runnning:

```console
kubectl exec -it on-prem-fluentd-0 -- ls -l /var/log/snyk/logs
```

Then copy the log file you want to fetch by running:

```console
kubectl cp <your-namespace>/<your-release>-fluentd-0:/var/log/snyk/logs/<file-name> ./<target-file-name>
```

NOTE: It may take a few minutes to copy all files

## Uninstalling Snyk Code Local Engine

To uninstall/delete the my-release resources:

```bash
helm delete my-release
```

The command removes all the Kubernetes components associated with the chart and deletes the release. Use the option `--purge` to delete all history too.
